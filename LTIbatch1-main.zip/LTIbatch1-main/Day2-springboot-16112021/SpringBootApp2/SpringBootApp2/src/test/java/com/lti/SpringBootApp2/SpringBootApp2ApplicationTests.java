package com.lti.SpringBootApp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootApp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
