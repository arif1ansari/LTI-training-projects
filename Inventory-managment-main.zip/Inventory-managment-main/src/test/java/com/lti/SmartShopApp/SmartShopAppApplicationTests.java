package com.lti.SmartShopApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartShopAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
