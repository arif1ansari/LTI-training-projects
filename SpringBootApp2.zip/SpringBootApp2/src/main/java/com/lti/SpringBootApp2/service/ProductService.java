package com.lti.SpringBootApp2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.SpringBootApp2.dao.ProductDao;
import com.lti.SpringBootApp2.model.Product;


@Service
public class ProductService {
	@Autowired
	ProductDao productDao;
	
	public Product addProduct(Product product) {
		return productDao.addProduct(product);
	}
	
	
	public List<Product> getAllProducts() {
		return productDao.getallProducts();
		
	}


	public List<Product> updateProduct(Product product, Integer id) {
		return productDao.getUpdatedProduct(product,id);
		
	}


	public List<Product> deleteProduct(Integer id) {
		
		return productDao.deleteProduct(id);
	}


	public Product getSpecificProduct(Integer id) {
		return productDao.getSpecificProduct(id);
	}
	

}