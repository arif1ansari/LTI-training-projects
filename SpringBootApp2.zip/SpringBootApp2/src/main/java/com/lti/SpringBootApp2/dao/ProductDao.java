package com.lti.SpringBootApp2.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.SpringBootApp2.model.Product;


@Repository
public class ProductDao {
	
	public static ArrayList<Product> productList=new ArrayList<>();
	
	public Product addProduct(Product product) {
		productList.add(product);
		return product;
	}
	
	public List<Product> getallProducts() {
		return productList;
	}

	public List<Product> getUpdatedProduct(Product product, Integer id) {
		for(int i=0 ; i<productList.size(); i++) {
			Product p = productList.get(i);
			if(p.getId().equals(id)) {
				productList.set(i, product);
				
			}
		}
		
		return productList;
	}

	public List<Product> deleteProduct(Integer id) {
		productList.removeIf(t -> t.getId().equals(id));
		return productList;
	}

	public Product getSpecificProduct(Integer id) {
		return productList.stream().filter(t -> t.getId().equals(id)).findFirst().get();
	}

}